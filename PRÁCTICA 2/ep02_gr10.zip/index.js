var canCreatePreference = true;
var userIsLoggedIn = false;

var restaurantNames = ["The Frying Dutchman", "Uncle Moe's Family Feedbag", "Luigi's"];
var restaurantAddresses = ["123 State Street, Springfield, USA", "353 Center Street, Springfield, USA", "928 Long Street, Springfield, USA"];

/* --------------- CARGA DE SECCIONES --------------- */

function loadPersonalInformation(e)
{
	//e.preventDefault();
	// jsHTML/personalInformation.html
	document.getElementById('content').innerHTML = '<div><h2 class="cursor-default">Personal Information</h2><form name="changePersonalInfo" method="POST"><fieldset><div class="form-left"><div><label for="name">Name: </label><input type="text" name="name" id="name"></div><div><label for="birthday">Birthday: </label><input type="text" name="birthday" id="birthday"></div><div><label for="address">Address: </label><input type="text" name="address" id="address"></div><div><label for="password">Password: </label><input type="password" name="password" id="password"></div></div><div class="form-right"><div><label for="surname">Surname: </label><input type="text" name="surname" id="surname"></div><div><label for="phone">Phone: </label><input type="tel" name="phone" id="phone"></div><div><label for="email">Email: </label><input type="email" name="email" id="email"></div><div><label for="image">Image: </label><input type="file" name="image" id="image"></div></div><div><input class="formButton" type="button" id="changePersonalInfoButton" value="Send" onclick="updateLocalData()"></div></fieldset></form></div><div><h2 class="cursor-default">My Activity in the App</h2><div class="activity-container"><div class="activity"><p>X</p><p>Points</p></div><div class="activity"><p>2</p><p>Level</p></div><div class="activity"><p>3</p><p>Opinions</p></div><div class="activity"><p>5</p><p>Photos</p></div></div></div>';
	refreshFromLocalData("personalInformation");
}

function loadLastOpinions()
{
	// jsHTML/lastOpinions.html
	document.getElementById('content').innerHTML = '<h2 id="cursor-default">Last Opinions</h2><div class="opinion"><div class="restaurant-info"><img src="images/theFryingDutchman.jpg" alt="The Frying Dutchman"><div><p>The Frying Dutchman</p><p>Springfield, USA</p><p>27 April 2016</p></div></div><p>The restaurant is notorious for its poorly-prepared seafood. Homer Simpson gave the restaurant a bad review, but despite the Captain&apos;s hatred of Homer for giving the bad review, he placed the bad review on the door anyway, as it was a convenient way to cover up the "D" from the Health Inspection Agency.</p></div><div class="opinion"><div class="restaurant-info"><img src="images/uncleMoesFamilyFeedbag.jpg" alt="Uncle Moe&apos;s Family Feedbag"><div><p>Uncle Moe&apos;s Family Feedbag</p><p>Springfield, USA</p><p>3 April 2016</p></div></div><p>"An alligator wearing sunglasses? Now I&apos;ve seen everything." PD. The owner is very ugly.</p></div><div class="opinion"><div class="restaurant-info"><img src="images/luigis.png" alt="Luigi&apos;s"><div><p>Luigi&apos;s</p><p>Springfield, USA</p><p>20 January 2016</p></div></div><p>In addition to Italian cuisine, Luigi&apos;s also serves fresh lobsters which customers may select from a tank. In Luigi&apos;s, you can choose your pizza toppings.</p></div>';
}

function loadLogIn()
{
	// jsHTML/logIn.html
	document.querySelector('#megadiv').innerHTML = '<div><form name="formLogIn" method=POST><h2>Log In</h2><fieldset><div><label for="email-login">Email: </label><input type="email" name="email-login" id="email-login"></div><div><label for="password-login">Password: </label><input type="password" name="password-login" id="password-login"></div><div><input type="button" class="formButton" name="log-in" value="Log In" onclick="validateFormLogIn()"></div></fieldset></form></div>';
	fixFooter();

	document.querySelector('input[name="email-login"]').focus();
}

function loadSignUp()
{
	// jsHTML/singUp.html
	document.querySelector('#megadiv').innerHTML = '<div><form name="formSignUp" method="POST" enctype="multipart/form-data"><h2>Sign Up</h2><fieldset><div><label for="username">Username: </label><input type="text" name="username" id="username"></div><div><label for="password">Password: </label><input type="password" name="password" id="password"></div><div><label for="name">Name: </label><input type="text" name="name" id="name"></div><div><label for="surname">Surname: </label><input type="text" name="surname" id="surname"></div><div><label for="email">Email: </label><input type="text" name="email" id="email"></div><div><label for="birthday">Birthday: </label><input type="text" name="birthday" id="birthday"></div><div><label for="image">Image: </label><input type="file" name="image" id="image"></div><div><label for="address">Address: </label><input type="text" name="address" id="address"></div><div><input type="checkbox" name="conditions" id="conditions" value="Conditions"><label for="conditions">I accept the terms and conditions</label></div><div><input class="formButton" type="button" name="save" value="Save" onclick="validateFormSignUp()"><input class="formButton" type="reset" name="delete" value="Delete"></div></fieldset></form></div>';
	//document.querySelector("#background-image").style.height = "100%";	
	unfixFooter();
}

function loadPrincipalPage()
{
	// jsHTML/principalPage.html
	document.querySelector('#megadiv').innerHTML = '<img src="images/globexPrincipalPage.jpg" id="background-image" alt="Globex Principal Page&apos;s image">';
	fixFooter();
}

function loadHomeRegisteredPage()
{
	// jsHTML/homePage.html
	document.querySelector("#megadiv").innerHTML = '<aside><div id="personal-information" class="border-down"><div class="profile"><img src="images/user.png" alt="Hank Scorpio&apos;s profile image"><p class="cursor-default">Hank Scorpio</p></div><h2 class="js-link">Personal Information</h2><p>- Name: Hank Scorpio</p><p>- Nationality: American</p><p>- Member since: 1996</p><p>- Profession: Philanthropist</p></div><div id="last-opinions" class="border-down"><h2 class="js-link">Last Opinions</h2><h3 class="restaurant-link">The Frying Dutchman</h3><p>The restaurant is notorious for its poorly-prepared seafood. Homer Simpson gave the restaurant a bad review, but despite the Captain&apos;s hatred of Homer for giving the bad review, he placed the bad review on the door anyway, as it was a convenient way to cover up the "D" from the Health Inspection Agency.</p><h3 class="restaurant-link">Uncle Moe&apos;s Family Feedbag</h3><p>"An alligator wearing sunglasses? Now I&apos;ve seen everything." PD. The owner is very ugly.</p><h3 class="restaurant-link">Luigi&apos;s</h3><p>In addition to Italian cuisine, Luigi&apos;s also serves fresh lobsters which customers may select from a tank. In Luigi&apos;s, you can choose your pizza toppings.</p></div><div class="preferences"><h2 id="cursor-default">My Preferences</h2><button id="add-btn">+</button><div id="preferences-container"><div class="preference"><p>Weekend</p><button class="close-btn">X</button></div><div class="preference"><p>Friends</p><button class="close-btn">X</button></div><div class="preference"><p>Volunteer</p><button class="close-btn">X</button></div><div class="preference"><p>World Domination</p><button class="close-btn">X</button></div></div></div></aside><div id="content"><div id="search"><div><input type="text" name="searchbox" placeholder="Search for restaurants"></div><div id="search-results"></div></div><div id="gallery"><div id="links"><a href="images/uncleMoesFamilyFeedbag.jpg" title="Uncle Moe&apos;s Family Feedbag"></a><a href="images/luigis.png" title="Luigi&apos;s"></a><a href="images/theFryingDutchman.jpg" title="The Frying Dutchman"></a></div><!-- The Gallery as inline carousel, can be positioned anywhere on the page --><div id="blueimp-gallery-carousel" class="blueimp-gallery blueimp-gallery-carousel"><div class="slides"></div><h3 class="title"></h3><a class="prev">‹</a><a class="next">›</a><a class="play-pause"></a><ol class="indicator"></ol></div></div></div>';
	refreshFromLocalData("homeRegistered");

	unfixFooter();

	//Eventos para cargar la seccion derecha
	document.querySelector('#personal-information h2').addEventListener('click', loadPersonalInformation, false);
	document.querySelector('#last-opinions h2').addEventListener('click', loadLastOpinions, false);
	document.getElementById("add-btn").addEventListener('click', addPreference, false);
	
	//Eventos para poder cargar los popups de los restaurantes
	var restNames = document.getElementsByClassName('restaurant-link');
	for (var i = 0; i < restNames.length; i++) {
		restNames[i].addEventListener('click', loadRestaurantPopup, false);
	}

	//Eventos para poder borrar las preferencias que ya estaban antes
	var buttons = document.getElementsByClassName('close-btn');
	for (var i = 0; i < buttons.length; i++) {
		buttons[i].addEventListener('click', removePreference, false);
	}



	blueimp.Gallery(document.getElementById('links').getElementsByTagName('a'),
			{
				container: '#blueimp-gallery-carousel',
				carousel: true
			}
		);


	$("#search input").keyup(function(){
		var query = $(this).val();

		if(query.length == 0)
		{
			$("#search-results").empty();
			return;
		}

		var willShow = [];
		for(var i = 0; i < restaurantNames.length; i++)
			willShow.push(false);

		for(var i = 0; i < restaurantNames.length; i++)
		{
			if(restaurantNames[i].toLowerCase().includes(query.toLowerCase()))
				willShow[i] = true;
		}

		for(var i = 0; i < restaurantNames.length; i++)
		{
			if(restaurantAddresses[i].toLowerCase().includes(query.toLowerCase()))
				willShow[i] = true;	
		}


		$("#search-results").empty();

		for(var i = 0; i < restaurantNames.length; i++)
		{
			if(willShow[i])
			{
				$("#search-results").append("<div><a>" + restaurantNames[i] + ", " + restaurantAddresses[i] +  "</a></div>");
			}
		}

		$("#search-results div").click(loadRestaurantPopupName("Luigis"));

	});

}

function loadHomePage()
{
	if(userIsLoggedIn)
	{
		loadHomeRegisteredPage();
	}
	else
	{
		loadPrincipalPage();
	}
}

function fixFooter()
{
	//Poner el footer fijo abajo
	document.querySelector("footer").style.position = "fixed";
	document.querySelector("footer").style.bottom = "0px";
	document.querySelector("footer").style.width = "100%";

	//poner la barra fija abajo
	document.querySelector(".bar").style.position = "fixed";
	document.querySelector(".bar").style.bottom = "88px";
	document.querySelector(".bar").style.width = "100%";
}

function unfixFooter()
{
	//Poner el footer fijo abajo
	document.querySelector("footer").style.position = "";
	document.querySelector("footer").style.bottom = "";
	document.querySelector("footer").style.width = "";

	//poner la barra fija abajo
	document.querySelector(".bar").style.position = "";
	document.querySelector(".bar").style.bottom = "";
	document.querySelector(".bar").style.width = "";
}

/* --------------- INICIO Y CIERRE DE SESION --------------- */

function changeHeaderButtonsRegistered()
{
	//Cambiar boton de login por logout
	document.querySelector('#login').removeEventListener('click', loadLogIn, false);
	document.querySelector("#login").innerHTML = "Log Out";
	document.querySelector("#login").id = "logout";
	document.querySelector("#logout").addEventListener('click', logOut, false);
	
	//Cambiar boton signup por personal page
	document.querySelector('#signup').removeEventListener('click', loadSignUp, false);
	document.querySelector("#signup").innerHTML = "User Page";
	document.querySelector("#signup").id = "homePage";
	document.querySelector("#homePage").addEventListener('click', loadHomeRegisteredPage, false);
}

function changeHeaderButtonsUnregistered()
{
	//Cambiar boton logout por login
	document.querySelector('#logout').removeEventListener('click', logOut, false);
	document.querySelector('#logout').innerHTML = "Log In";
	document.querySelector('#logout').id = "login";
	document.querySelector('#login').addEventListener('click', loadLogIn, false);

	//Cambiar boton personalHome por signup
	document.querySelector('#homePage').removeEventListener('click', loadHomeRegisteredPage, false);
	document.querySelector('#homePage').innerHTML = "Sign Up";
	document.querySelector('#homePage').id = "signup";
	document.querySelector('#signup').addEventListener('click', loadSignUp, false);
}

function logOut()
{
	changeHeaderButtonsUnregistered();

	updateSavedPreferences();

	//Recargar la pagina
	userIsLoggedIn = false;
	loadHomePage();
	
}

function validateFormLogIn()
{
	if(localStorage.getItem("email") === document.forms["formLogIn"]["email-login"].value & 
		localStorage.getItem("password") == document.forms["formLogIn"]["password-login"].value)
	{
		userIsLoggedIn = true;
		loadHomePage();

		changeHeaderButtonsRegistered();
	}
	else
	{
		alert("Credentials are not correct");
	}
}

/* --------------- REGISTRO --------------- */

function isValidEmail(mail)
{
	return /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/.test(mail);
}

function isValidBirthday(birthday)
{
	return /^([0-9]{2}\/){2}[0-9]{4}$/.test(birthday);
}

function validateFormSignUp()
{
	if (document.forms["formSignUp"]["username"].value == "")
	{
		alert("Username must be filled out");
		return false;
	}
	if (!document.forms["formSignUp"]["password"].value.match("^[a-z0-9]{1,8}$"))
	{
		alert("Password must have a maximum length of 8 characters between a-z and 0-9");
		return false;
	}
	if (document.forms["formSignUp"]["name"].value == "")
	{
		alert("Name must be filled out");
		return false;
	}
	if (document.forms["formSignUp"]["surname"].value == "")
	{
		alert("Surname must be filled out");
		return false;
	}
	if (!isValidEmail(document.forms["formSignUp"]["email"].value))
	{
		alert("Email must have the format name@domain.extension");
		return false;
	}
	if (!isValidBirthday(document.forms["formSignUp"]["birthday"].value))
	{
		alert("Birthday must have the format dd/mm/aaaa");
		return false;
	}
	if (document.forms["formSignUp"]["address"].value == "")
	{
		alert("Address must be filled out");
		return false;
	}
	if (!document.forms["formSignUp"]["conditions"].checked)
	{
		alert("You must accept the terms and conditions");
		return false;
	}

	//Todos los valores del formulario son correctos

	updateLocalData();

	changeHeaderButtonsRegistered();

	userIsLoggedIn = true;
	loadHomePage();
}

/* --------------- DATOS LOCALES --------------- */
function updateLocalData()
{
	var fields = document.querySelectorAll("form input");
	for (var i = 0; i < fields.length; i++) {
		if(fields[i].value != "")
			localStorage.setItem(fields[i].name, fields[i].value);
	}

	//Quitar datos innecesarios del localStore
	localStorage.removeItem("conditions");
	localStorage.removeItem("save");
	localStorage.removeItem("delete");

	//Guardar preferencias
	updateSavedPreferences();

	loadHomePage();
}

function updateSavedPreferences()
{
	var prefs = document.querySelector("#preferences-container");

	if(prefs !== null)
		localStorage.setItem("preferences", prefs.innerHTML);
	else
		localStorage.setItem("preferences", '<div class="preference"><p>Weekend</p><button class="close-btn">X</button></div><div class="preference"><p>Friends</p><button class="close-btn">X</button></div><div class="preference"><p>Volunteer</p><button class="close-btn">X</button></div><div class="preference"><p>World Domination</p><button class="close-btn">X</button></div>');
}

function refreshFromLocalData(pageName)
{
	switch(pageName)
	{
		case "personalInformation":
			var inputs = document.querySelectorAll("input");
			for(var i = 0; i < inputs.length; i++)
			{
				if(localStorage.getItem(inputs[i].name) !== null)
					inputs[i].value = localStorage.getItem(inputs[i].name);
			}
		break;
		case "homeRegistered":
			//Actualizacion del nombre de usuario
			document.querySelector(".profile p").innerHTML = localStorage.getItem("name") + " " + localStorage.getItem("surname");
			document.querySelector("#personal-information > p").innerHTML = "- Name: " + localStorage.getItem("name") + " " + localStorage.getItem("surname");

			//Actualizacion de las preferencias de usuario
			document.querySelector("#preferences-container").innerHTML = localStorage.getItem("preferences");

			var imgName = localStorage.getItem("image");

			if(imgName != null)
			{
				imgName = imgName.split("\\");
				document.querySelector("#personal-information img").src = "images/" + imgName[imgName.length-1];
			}
		break;
	}
}

/* --------------- POPUPS DE RESTAURANTES --------------- */

function loadRestaurantPopupName(resName)
{
	var newNode = document.createElement('div');
	newNode.id = "cover";
	newNode.innerHTML = '<div id="popup"><button id="close-popup">X</button><h2></h2><div class="restaurant"><img src=""><div id="properties"><p>Comment Address not Found</p><p>Comment Telephone Number not Found</p><p>Comment Web Page not Found</p><p>Comment Type of Food not found</p></div></div><p></p></div>';
	document.getElementsByTagName('body')[0].insertBefore(newNode, document.body.firstChild);
	document.getElementById('close-popup').addEventListener('click', closeRestaurantPopup, false);
	var propiedades = ["", "", "", ""];

	switch(resName)
	{
		case "The Frying Dutchman":
			document.querySelector('#popup img').src = "images/theFryingDutchman.jpg";
			document.querySelector('#popup > p').innerHTML = 'The restaurant is notorious for its poorly-prepared seafood. Homer Simpson gave the restaurant a bad review, but despite the Captain&apos;s hatred of Homer for giving the bad review, he placed the bad review on the door anyway, as it was a convenient way to cover up the "D" from the Health Inspection Agency.';
			propiedades[0] = "123 State Street, Springfield, USA";
			propiedades[1] = "916260192";
			propiedades[2] = "thefryingdutchman@yahoo.es";
			propiedades[3] = "Frying Fishing Food";
		break;
		case "Uncle Moe's Family Feedbag":
			document.querySelector('#popup img').src = "images/uncleMoesFamilyFeedbag.jpg";
			document.querySelector('#popup > p').innerHTML = '"An alligator wearing sunglasses? Now I&apos;ve seen everything." PD. The owner is very ugly.';
			propiedades[0] = "353 Center Street, Springfield, USA";
			propiedades[1] = "910102638";
			propiedades[2] = "unclemoes@alumnos.uc3m.es";
			propiedades[3] = "Very Frying Food";
		break;
		case "Luigi's":
			document.querySelector('#popup img').src = "images/luigis.png";
			document.querySelector('#popup > p').innerHTML = 'In addition to Italian cuisine, Luigi&apos;s also serves fresh lobsters which customers may select from a tank. In Luigi&apos;s, you can choose your pizza toppings.';
			propiedades[0] = "928 Long Street, Springfield, USA";
			propiedades[1] = "916253921";
			propiedades[2] = "luigitheitalian@gmail.com";
			propiedades[3] = "Italian Food";
		break;
	}

	var destinos = document.getElementById('properties').getElementsByTagName('p');
	document.querySelector("#popup h2").innerHTML = event.target.innerHTML;
	for (var i = destinos.length - 1; i >= 0; i--)
	{
		if(propiedades[i] !== "")
			destinos[i].innerHTML = propiedades[i];
	}
}

function loadRestaurantPopup(event)
{
	loadRestaurantPopupName(event.target.innerHTML);
}

function closeRestaurantPopup()
{
	document.getElementById('close-popup').removeEventListener('click', closeRestaurantPopup, false);	
	document.getElementsByTagName('body')[0].removeChild(document.getElementsByTagName('body')[0].firstChild);
}	

/* --------------- AÑADIR Y QUITAR PREFERENCIAS --------------- */

function addPreference()
{
	if(!canCreatePreference)
	{
		document.getElementById("preferences-container").lastChild.querySelector("p").focus()
		return;
	}
	canCreatePreference = false;
	var newNode = document.createElement("div");
	newNode.className = "preference";
	var aux = document.createElement("p");
	aux.contentEditable = true;
	newNode.appendChild(aux);
	aux = document.createElement("button");
	aux.className = "close-btn";
	aux.innerHTML = "X";
	aux.addEventListener('click', removePreference, false);
	newNode.appendChild(aux);
	document.getElementById('preferences-container').appendChild(newNode);
	document.addEventListener('keydown', finishEditingName, false);
	newNode.firstChild.focus();
}

function finishEditingName(event)
{
	if(event.which == 13)
	{
		event.preventDefault();
		var inputField = document.getElementById("preferences-container").lastChild.getElementsByTagName("p")[0];
		if(inputField.innerHTML === "")
		{
			inputField.focus();
			return;
		}
		document.removeEventListener('keydown', finishEditingName, false);
		inputField.contentEditable = false;
		canCreatePreference = true;

		updateSavedPreferences();
	}
}

function removePreference(event)
{
	if(canCreatePreference || event.target === document.getElementById('preferences-container').lastChild.querySelector("button"))
	{
		document.getElementById('preferences-container').removeChild(event.target.parentNode);
		canCreatePreference = true;
	}
	else
	{
		document.getElementById("preferences-container").lastChild.getElementsByTagName("p")[0].focus();
	}

	updateSavedPreferences();
}


loadPrincipalPage();

/* --------------- EVENTOS DE LA PAGINA INICIAL --------------- */

document.querySelector('#login').addEventListener('click', loadLogIn, false);
document.querySelector('#signup').addEventListener('click', loadSignUp, false);
document.querySelector('header img').addEventListener('click', loadHomePage, false);


