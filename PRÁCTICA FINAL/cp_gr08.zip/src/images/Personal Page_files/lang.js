function cambioIdioma(lang){
    switch (lang) {
        case "es":
        $.getJSON("./lang/lang_es.json", function(json) {
            idioma(json)
        });
            break;
        case "eng":
        $.getJSON("./lang/lang_eng.json", function(json) {
            idioma(json)
        });
            break;
        default:
            alert("error cambio idioma");
            break;
    }
}

function idioma(json){

    for (id in json)
        if(id != "idioma" && $("#"+id).length !== 0)
            if($("#"+id).is("input[type=text]") || $("#"+id).is("input[type=search]"))
                document.getElementById(id).placeholder = json[id];
            else if($("#"+id).is("input[type=submit]"))
                document.getElementById(id).value = json[id];
            else
                document.getElementById(id).innerText = json[id];

}
