$(document).ready(function(){

    // console.log(window.name);

    if(window.name !== "")
    {
        var params = window.name.split(";");

        /* nombre imagen */
        $("#"+params[0].split("=")[0]).attr("src", params[0].split("=")[1]);

        /* nombre restaurante */
        $("#"+params[1].split("=")[0]).text(params[1].split("=")[1]);

        /* direccion */
        $("#"+params[2].split("=")[0]).text(params[2].split("=")[1]);

        /* pais */
        console.log(params[3].split("=")[0]);
        $("#"+params[3].split("=")[0]).text(params[3].split("=")[1]);

        /* mapa */
        $("#"+params[4].split("=")[0]).attr("src", params[4].substring(10));

    }

    $("#reservar").click(function(){
        if(checkCookie())
        {
            var strWindowFeatures = "resizable=yes,centerscreen=yes,width=975,height=900";
            window.open("FormPago/home.html", "Pago de Factura", strWindowFeatures);
        }
        else
        {
            generarpopup(1); //argumento 0 = formulario de registro y 1 formulario de login
            modal.style.display = "block";
            modal.style.paddingTop = "12%";
            // $('#megadiv').show();
            $("#sesionEMail").focus();
        }
    });


    /* modal para los popups */
    var modal = document.getElementById('myModal');


    $('#MenuAyuda').click(function(){
        modal.style.display = "block";
        modal.style.paddingTop = "2%";
        generarpopup(2);
    });

    /* evento del click en la x del popup para cerrarlo*/
    $('#close').click(function(){
        modal.style.display = "none";
        //document.getElementById('megadiv').hide();
        $('.form-Hidden:not(#userMenu)').hide();
        // $('#megadiv').hide();
    });
    // When the user clicks anywhere outside of the modal, close it
    window.addEventListener("click", function(event) {

        if (event.target == modal) {
            modal.style.display = "none";
            //document.getElementById('megadiv').hidden();
            $('.form-Hidden:not(#userMenu)').hide();
            // $('#megadiv').hide();
        }
    });


    /*Si pincha en el logo la pagina vuelve como si hubiera sido recien abierta*/
    $('#ImgHeader').click(function(){
        window.location.href = "index.html";
    });

    $('#LengEsp').click(function(){
        cambioIdioma("es");
    });
    $('#LengEng').click(function(){
        cambioIdioma("eng");
    });


    //Click en registro para que aparezca un popup con el formulario
    $('#registro').click(function(){
        generarpopup(0); //argumento 0 = formulario de registro y 1 formulario de login
        modal.style.display = "block";
        modal.style.paddingTop = "2%";
        // $('#megadiv').show();
        $("#altaUsuario").focus();

    });

    //Click en login para que aparezca un popup con el formulario
    $('#login').click(function(){
        generarpopup(1); //argumento 0 = formulario de registro y 1 formulario de login
        modal.style.display = "block";
        modal.style.paddingTop = "12%";
        // $('#megadiv').show();
        $("#sesionEMail").focus();

    });

    /* AUTO-LOGIN */
    if(checkCookie())
    {
        loadUserMenu();
    }


    $("#userMenu h2").click(function(){
        $("#userOptionsContainer").toggle();
    });

    $("#userOptionProfile").click(function(){
        window.location.href = "personalPage.html";
    });

    $("#userOptionLogout").click(function(){
        $("#registro").show();
        $("#login").show();
        $("#userMenu").hide();
        $("#userOptionsContainer").hide();

        /* borrar cookies para no hacer auto-login*/
        clearCookies();

    });

    /**array valores guardar en cookies */
    var datosCookie = ["Usuario","Contrasena","Nombre","Apellido","Email","Fecha","Imagen","Dir"];

    $('#formAlta').submit(function(event){
        event.preventDefault();
        var valido = true;

        /* verificar con html los inputs*/
        // for (var i = 0; i < document.forms['formSignUp'].length; i++) {
        //     console.log("Campo: " + document.forms['formSignUp'][i]);
        // }



        for (var i = 0; i < datosCookie.length; i++) {
            var item = document.forms['formAlta']["Usuario"];
            console.log("reviso "+item.value);
                if(!item.checkValidity())
                    valido = false;
        }

        /* verificamos el checkbox*/
        if(valido && document.forms['formAlta']['conditions'].checked){

            if(localStorage.length === 0)
            {
                $.getJSON("./users.json", function(users){
                    register(users);
                });
            }
            else
            {
                register(JSON.parse(localStorage.getItem("JSONusuarios")));
            }
        }
        else {
            alert("Por favor rellene los campos correctamente y acepte las condiciones");
        }

    });

    $('#formLogin').submit(function(event){
        event.preventDefault();

        if(localStorage.length === 0)
        {
            $.getJSON("./users.json", function(users){
                logIn(users);
            });
        }
        else
        {
            logIn(JSON.parse(localStorage.getItem("JSONusuarios")));
        }

    });




});


function loadSignUp()
{
    document.getElementById("formAlta").reset();
    $('#formSignUp').show();
}

function loadLogIn()
{
    document.getElementById("formLogin").reset();
    $('#formLogInDiv').show();
}

function loadUserMenu()
{
    $("#registro").hide();
    $("#login").hide();
    $('#close').click();
    // alert("Hola "+getCookie("usuario"));
    // document.getElementById("nombre").innerText = "Hola " + getCookie("usuario");
    if(getCookie("imagen") !== "")
        $("#userMenu img").attr("src", getCookie("imagen"));
    else
        $("#userMenu img").attr("src", "images/logo2.png");

    // $("#userMenu h2").text("Hola " + getCookie("usuario") + " &#9660;");

    document.querySelector("#userMenu h2").innerHTML = getCookie("usuario") + "    &#9660;";

    $("#userMenu").css("display", "flex");

}

function logIn(users) //users: JSON con los usuarios
{
    var username = $("#formLogin input[name=email-login]").val();
    var password = $("#formLogin input[name=password-login]").val();

    if(typeof(users[username]) !== "undefined")
    {
        if(users[username].contrasena == password)
        {
            //guardar cookies
            var entries = Object.entries(users[username]);
            for(var i = 0; i < entries.length; i++)
                setCookie(entries[i][0], entries[i][1], 365);

            loadUserMenu();
        }
        else
        {
            alert("La contraseña no es correcta");
        }
    }
    else
    {
        alert("El usuario no existe");
    }
}

function generarpopup(tipo_form){

    if(tipo_form == 0){
        loadSignUp();
    }else if(tipo_form == 1){
        loadLogIn();
    }else if(tipo_form == 2){

        $('#Faq').show();
        console.log("POPUP");
    }
}

/* verificar si existe un usuario logueado.
si lo hay verifica si la cookie es correcta*/
function checkCookie() {

    var cookieValues = document.cookie.split(";");

    if(cookieValues.length != 8)
        return false;

    if(getCookie("usuario") === "")
        return false;

    // $.getJSON("./users.json", function(users){
    //
    //     var username = getCookie("usuario");
    //
    //     if(typeof(users[username]) !== "undefined")
    //     {
    //         var jsonValues = Object.entries(users[username]);
    //
    //         for(var i = 0; i < jsonValues.length; i++)
    //             if(cookieValues[i].split("=")[0] !== jsonValues[i][0] ||
    //             cookieValues[i].split("=")[1] !== jsonValues[i][1])
    //                 return false;
    //     }
    //     else
    //         return false;
    // });

    return true;
}

/**Sacar valores por parametro */
function getCookie(cname) {
//console.log("entro en getcookie");
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
    // console.log(i+ca[i]);
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
        //  console.log(c);
            return c.substring(name.length, c.length);
        }
    }
// console.log("no habia na");
    return "";
}

function clearCookies()
{
    var cookies = document.cookie.split(";");
    for (var i = 0; i < cookies.length; i++)
        setCookie(cookies[i].split("=")[0], cookies[i].split("=")[1], -1);
}

function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}
