$(document).ready(function(){

    /* modal para los popups */
    var modal = document.getElementById('myModal');

    /* Rellena y configura el menu de usuario */
    if(getCookie("imagen") !== "")
        $("#userMenu img").attr("src", getCookie("imagen"));
    else
        $("#userMenu img").attr("src", "images/logo2.png");

    document.querySelector("#userMenu h2").innerHTML = getCookie("usuario") + "    &#9660;";
    $("#userMenu").css("display", "flex");

    $("#userMenu h2").click(function(){
        $("#userOptionsContainer").toggle();
    });

    $("#userOptionProfile").click(function(){
        window.location.href = "personalPage.html";
    });

    $("#userOptionLogout").click(function(){
        /* borrar cookies para no hacer auto-login*/
        clearCookies();

        /* saltar a index.html */
        window.location.href = "index.html"
    });

    /* rellenar los campos del usuario */
    $("#personalParams p.property").each(function(){
        $(this).text(getCookie($(this).prevAll("form:first").attr("name")));
    });

    $("#personalParams p.property:first").text(getCookie("usuario"));
    $("#profileUser h2")[0].innerHTML = getCookie("usuario");

    if(getCookie("imagen") !== "")
        $("#profileUser img").attr("src", getCookie("imagen"));
    else
        $("#profileUser img").attr("src", "images/logo2.png");

    $(".enable-edit-property").click(function(event){
        $(this).nextAll("p:first").hide();
        $(this).next("form").children("input[type=text]:first").val($(this).nextAll("p:first").text());
        $(this).next("form").css("display", "flex");
        $(this).next("form").children("input[type=text]:first").focus();
        $(".enable-edit-property").hide();
    });

    $(".edit-property").submit(function(event){
        event.preventDefault();

        var newVal = $(this).children("input[type=text]:first").val();

        $(this).next("p").text(newVal);
        $(this).hide();
        $(this).next("p").show();
        $(".enable-edit-property").show();

        if(newVal !== "" || $(this).attr("name") === "direccion" || $(this).attr("name") === "fechaNac" || $(this).attr("name") === "imagen")
        {
            /* asignar valor en la cookie */
            setCookie($(this).attr("name"), newVal, 365);

            /* asignar valor en el JSON de usuarios */
            /* hay que actualizarlo sobre el localStorage */
            if(localStorage.length === 0)
            {
                var originalForm = $(this);

                $.getJSON("./users.json", function(users){
                    users[getCookie("usuario")][originalForm[0].getAttribute("name")] = newVal;

                    /* Como no puedo guardar un fichero físico guardo
                    el json resultante en el localStorage */
                    localStorage.setItem("JSONusuarios", getCookie("JSONusuarios"))
                    console.log("dentro:" + localStorage);
                });

                console.log("fuera:" + localStorage);

            }
            else
            {
                var users = JSON.parse(localStorage.getItem("JSONusuarios"));
                users[getCookie("usuario")][$(this).attr("name")] = newVal;

                /* Como no puedo guardar un fichero físico guardo
                el json resultante en el localStorage */
                localStorage.setItem("JSONusuarios", JSON.stringify(users));
            }
        }

        /* refresca la pagina */
        location.reload();

    });


    $("#MenuPerfil").click(function(){
        window.location.href = "personalPage.html";
    });

    $('#MenuAyuda').click(function(){
        modal.style.display = "block";
        modal.style.paddingTop = "2%";
        generarpopup(2);
    });

    /* evento del click en la x del popup para cerrarlo*/
    $('#close').click(function(){
        modal.style.display = "none";
        //document.getElementById('megadiv').hide();
        $('.form-Hidden:not(#userMenu)').hide();
        // $('#megadiv').hide();
    });
    // When the user clicks anywhere outside of the modal, close it
    window.addEventListener("click", function(event) {

        if (event.target == modal) {
            modal.style.display = "none";
            //document.getElementById('megadiv').hidden();
            $('.form-Hidden:not(#userMenu)').hide();
            // $('#megadiv').hide();
        }
    });


    /*Si pincha en el logo la pagina vuelve como si hubiera sido recien abierta*/
    $('#ImgHeader').click(function(){
        window.location.href = "index.html";
    });

    $('#LengEsp').click(function(){
        cambioIdioma("es");
    });
    $('#LengEng').click(function(){
        cambioIdioma("eng");
    });

});

function generarpopup(tipo_form){

    if(tipo_form == 0){
        loadSignUp();
    }else if(tipo_form == 1){
        loadLogIn();
    }else if(tipo_form == 2){

        $('#Faq').show();
        console.log("POPUP");
    }
}

/**Sacar valores por parametro */
function getCookie(cname) {
//console.log("entro en getcookie");
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
    // console.log(i+ca[i]);
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
        //  console.log(c);
            return c.substring(name.length, c.length);
        }
    }
// console.log("no habia na");
    return "";
}

function clearCookies()
{
    var cookies = document.cookie.split(";");
    for (var i = 0; i < cookies.length; i++)
        setCookie(cookies[i].split("=")[0], cookies[i].split("=")[1], -1);
}

function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}
