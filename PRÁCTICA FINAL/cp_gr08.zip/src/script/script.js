/* eventos y cargar de jquery en la pagina */
$(document).ready(function(){
    // formularios ocultos desde el inicio
    // $('.form-Hidden').hide();
    //ahora esto esta en el css

    autocomplete(document.getElementById("InputBuscador"), countries);
    // variable que usa el div para el popup
    var modal = document.getElementById('myModal');

    //Click en registro para que aparezca un popup con el formulario
    $('#registro').click(function(){
        generarpopup(0); //argumento 0 = formulario de registro y 1 formulario de login
        modal.style.display = "block";
        modal.style.paddingTop = "2%";
        // $('#megadiv').show();
        $("#altaUsuario").focus();

    });

    //Click en login para que aparezca un popup con el formulario
    $('#login').click(function(){
        generarpopup(1); //argumento 0 = formulario de registro y 1 formulario de login
        modal.style.display = "block";
        modal.style.paddingTop = "12%";
        // $('#megadiv').show();
        $("#sesionEMail").focus();

    });

    /* evento del click en la x del popup para cerrarlo*/
    $('#close').click(function(){
        modal.style.display = "none";
        //document.getElementById('megadiv').hide();
        $('.form-Hidden:not(#userMenu)').hide();
        // $('#megadiv').hide();
    });
    // When the user clicks anywhere outside of the modal, close it
    window.addEventListener("click", function(event) {

        if (event.target == modal) {
            modal.style.display = "none";
            //document.getElementById('megadiv').hidden();
            $('.form-Hidden:not(#userMenu)').hide();
            // $('#megadiv').hide();
        }
    });

    /* AUTO-LOGIN */
    if(checkCookie())
    {
        loadUserMenu();
    }

    //A continuación se va implementar las funciones para poder ir cambiando entre los menus de la pagina web
    $('#MenuRestaurante').click(function(){

        $('#MenuHotel').css("text-decoration","none");
        $('#MenuRestaurante').css("text-decoration","underline");
        $('#MenuAyuda').css("text-decoration","none");

        $('#CuerpoHoteles').hide();
        $('#CuerpoRestaurantes').show();
        $('#CuerpoAyuda').hide();

    });

    $('#MenuHotel').click(function(){

        $('#MenuRestaurante').css("text-decoration","none");
        $('#MenuHotel').css("text-decoration","underline");
        $('#MenuAyuda').css("text-decoration","none");

        $('#CuerpoRestaurantes').hide();
        $('#CuerpoHoteles').show();
        $('#CuerpoAyuda').hide();

    });

    $('#MenuAyuda').click(function(){

        $('#MenuRestaurante').css("text-decoration","none");
        $('#MenuAyuda').css("text-decoration","underline");
        $('#MenuHotel').css("text-decoration","none");



        $('#CuerpoRestaurantes').hide();
        $('#CuerpoHoteles').hide();
        $('#CuerpoAyuda').show();
        modal.style.display = "block";
        modal.style.paddingTop = "2%";
        generarpopup(2);
        // $('#megadiv').show();
        // bajar el documento para ver keep calm
        $(document).scrollTop($(document).height());
    });


    $("#userMenu h2").click(function(){
        $("#userOptionsContainer").toggle();
    });

    $("#userOptionProfile").click(function(){
        window.location.href = "personalPage.html";
    });

    $("#userOptionLogout").click(function(){
        $("#registro").show();
        $("#login").show();
        $("#userMenu").hide();
        $("#userOptionsContainer").hide();

        /* borrar cookies */
        clearCookies();
    });

    /*Si pincha en el logo la pagina vuelve como si hubiera sido recien abierta*/
    $('#ImgHeader').click(function(){

        $('#MenuRestaurante').css("text-decoration","none");
        $('#MenuHotel').css("text-decoration","underline");
        $('#MenuAyuda').css("text-decoration","none");

        $('#CuerpoRestaurantes').hide();
        $('#CuerpoHoteles').show();
        $('#CuerpoAyuda').hide();

    });

    $('#BotonBuscador').click(function(){
        var a = document.getElementById("InputBuscador").value;
        if (a != '')
            window.open("https://www.google.es/search?q="+a);
    });

    $('#LengEsp').click(function(){
        cambioIdioma("es");
    });
    $('#LengEng').click(function(){
        cambioIdioma("eng");
    });

    var busca = document.getElementById("InputBuscador");

    busca.onkeypress = function(e){
        if (e.keyCode === 13){

            $('#BotonBuscador').click();
            busca.value="";
        }
    }

    $("#paginaResHotel").click(function(event){

        var nombreHotel = event.target.parentNode.parentNode.parentNode.getElementsByTagName("h2")[0].innerHTML;
        var idHotel = event.target.parentNode.parentNode.getElementsByTagName("img")[0].getAttribute("data-id");

        var datos = "hotelImage=";
        //datos += event.target.parentNode.parentNode.getElementsByTagName("img")[0].src.split("/")[8];
        datos += $("#" + idHotel).attr("src");
        datos += ";hotelName=";
        datos += nombreHotel;

        datos += ";hotelAddress="
        datos += $("#" + idHotel).attr("data-address");

        datos += ";hotelCountry="
        datos += $("#" + idHotel).attr("data-country");

        datos += ";hotelMaps="
        datos += $("#" + idHotel).attr("data-maps");

        window.open("./hotelPage.html", datos);
    });

    //Codigo para los carruseles
    /*C1*/
    var imgItem = $('#CARR1 li').length;
    var imgPos = 1;
    var imgPos2 = 1;
    var imgPos3 = 1;
    var imgPos4 = 1;
    var imgPos5 = 1;
    var imgPos6 = 1;

    $('.photos_b li').hide();
    $('.photos_b li:nth-child(1)').show();
    $('.photos_b li:nth-child(2)').show();
    $('.photos_b li:nth-child(3)').show();

    $('.left1 span').click(function(){
        prevImg(1)});
    $('.right1 span').click(function(){
        nextImg(1)});
    $('.left2 span').click(function(){
        prevImg(2)});
    $('.right2 span').click(function(){
        nextImg(2)});
    $('.left3 span').click(function(){
        prevImg(3)});
    $('.right3 span').click(function(){
        nextImg(3)});
    $('.left4 span').click(function(){
        prevImg(4)});
    $('.right4 span').click(function(){
        nextImg(4)});
    $('.left5 span').click(function(){
        prevImg(5)});
    $('.right5 span').click(function(){
        nextImg(5)});
    $('.left6 span').click(function(){
        prevImg(6)});
    $('.right6 span').click(function(){
        nextImg(6)});

    function nextImg(carrusel){

        if(carrusel == 1){

            if(imgPos+3 >= imgItem){
                imgPos = 1;
            }else{
                imgPos+=3;
            }

            $('#CARR1 li').hide();//login
            $('#CARR1 li:nth-child('+imgPos+')').fadeIn();
            $('#CARR1 li:nth-child('+(imgPos+1)+')').fadeIn();
            $('#CARR1 li:nth-child('+(imgPos+2)+')').fadeIn();



        }else if(carrusel == 2){

            if(imgPos2+3 >= imgItem){
                imgPos2 = 1;
            }else{
                imgPos2+=3;
            }

            $('#CARR2 li').hide();
            $('#CARR2 li:nth-child('+imgPos2+')').fadeIn();
            $('#CARR2 li:nth-child('+(imgPos2+1)+')').fadeIn();
            $('#CARR2 li:nth-child('+(imgPos2+2)+')').fadeIn();

        }else if(carrusel == 3){

            if(imgPos3+3 >= imgItem){
                imgPos3 = 1;
            }else{
                imgPos3+=3;
            }

            $('#CARR3 li').hide();
            $('#CARR3 li:nth-child('+imgPos3+')').fadeIn();
            $('#CARR3 li:nth-child('+(imgPos3+1)+')').fadeIn();
            $('#CARR3 li:nth-child('+(imgPos3+2)+')').fadeIn();
        }else if(carrusel == 4){


            if(imgPos4+3 >= imgItem){
                imgPos4 = 1;
            }else{
                imgPos4+=3;
            }

            console.log(imgPos4);

            $('#CARR4 li').hide();
            $('#CARR4 li:nth-child('+imgPos4+')').fadeIn();
            $('#CARR4 li:nth-child('+(imgPos4+1)+')').fadeIn();
            $('#CARR4 li:nth-child('+(imgPos4+2)+')').fadeIn();

        }else if(carrusel == 5){

            if(imgPos5+3 >= imgItem){
                imgPos5 = 1;
            }else{
                imgPos5+=3;
            }

            $('#CARR5 li').hide();
            $('#CARR5 li:nth-child('+imgPos5+')').fadeIn();
            $('#CARR5 li:nth-child('+(imgPos5+1)+')').fadeIn();
            $('#CARR5 li:nth-child('+(imgPos5+2)+')').fadeIn();

        }else if(carrusel == 6){

            if(imgPos6+3 >= imgItem){
                imgPos6 = 1;
            }else{
                imgPos6+=3;
            }

            $('#CARR6 li').hide();
            $('#CARR6 li:nth-child('+imgPos6+')').fadeIn();
            $('#CARR6 li:nth-child('+(imgPos6+1)+')').fadeIn();
            $('#CARR6 li:nth-child('+(imgPos6+2)+')').fadeIn();
        }
   }

   function prevImg(carrusel){



        if(carrusel == 1){

            if(imgPos-3 < 1){
                imgPos = 4;
            }else{
                imgPos-=3;
            }
            console.log(imgPos);
            $('#CARR1 li').hide();
            $('#CARR1 li:nth-child('+imgPos+')').fadeIn();
            $('#CARR1 li:nth-child('+(imgPos+1)+')').fadeIn();
            $('#CARR1 li:nth-child('+(imgPos+2)+')').fadeIn();



        }else if(carrusel == 2){

            if(imgPos2-3 < 1){
                imgPos2 = 4;
            }else{
                imgPos2-=3;
            }

            $('#CARR2 li').hide();
            $('#CARR2 li:nth-child('+imgPos2+')').fadeIn();
            $('#CARR2 li:nth-child('+(imgPos2+1)+')').fadeIn();
            $('#CARR2 li:nth-child('+(imgPos2+2)+')').fadeIn();

        }else if(carrusel == 3){

            if(imgPos3-3 < 1){
                imgPos3 = 4;
            }else{
                imgPos3-=3;
            }

            $('#CARR3 li').hide();
            $('#CARR3 li:nth-child('+imgPos3+')').fadeIn();
            $('#CARR3 li:nth-child('+(imgPos3+1)+')').fadeIn();
            $('#CARR3 li:nth-child('+(imgPos3+2)+')').fadeIn();
        }else if(carrusel == 4){

            if(imgPos4-3 < 1){
                imgPos4 = 4;
            }else{
                imgPos4-=3;
            }

            $('#CARR4 li').hide();
            $('#CARR4 li:nth-child('+imgPos4+')').fadeIn();
            $('#CARR4 li:nth-child('+(imgPos4+1)+')').fadeIn();
            $('#CARR4 li:nth-child('+(imgPos4+2)+')').fadeIn();
        }else if(carrusel == 5){

            if(imgPos5-3 < 1){
                imgPos5 = 4;
            }else{
                imgPos5-=3;
            }

            $('#CARR5 li').hide();
            $('#CARR5 li:nth-child('+imgPos5+')').fadeIn();
            $('#CARR5 li:nth-child('+(imgPos5+1)+')').fadeIn();
            $('#CARR5 li:nth-child('+(imgPos5+2)+')').fadeIn();
        }else if(carrusel == 6){

            if(imgPos6-3 < 1){
                imgPos6 = 4;
            }else{
                imgPos6-=3;
            }

            $('#CARR6 li').hide();
            $('#CARR6 li:nth-child('+imgPos6+')').fadeIn();
            $('#CARR6 li:nth-child('+(imgPos6+1)+')').fadeIn();
            $('#CARR6 li:nth-child('+(imgPos6+2)+')').fadeIn();
        }

    }

    $('#foto1').hover(function(){
        $('#descr1').show();
    },function(){
        $('#descr1').hide();
    });

    $('#foto2').hover(function(){
        $('#descr2').show();
    },function(){
        $('#descr2').hide();
    });

    $('#foto3').hover(function(){
        $('#descr3').show();
    },function(){
        $('#descr3').hide();
    });

    $('#foto4').hover(function(){
        $('#descr4').show();
    },function(){
        $('#descr4').hide();
    });

    $('#foto5').hover(function(){
        $('#descr5').show();
    },function(){
        $('#descr5').hide();
    });

    $('#foto6').hover(function(){
        $('#descr6').show();
    },function(){
        $('#descr6').hide();
    });

    $('#foto7').hover(function(){
        $('#descr7').show();
    },function(){
        $('#descr7').hide();
    });

    $('#foto8').hover(function(){
        $('#descr8').show();
    },function(){
        $('#descr8').hide();
    });

    $('#foto9').hover(function(){
        $('#descr9').show();
    },function(){
        $('#descr9').hide();
    });

    $('#foto10').hover(function(){
        $('#descr10').show();
    },function(){
        $('#descr10').hide();
    });

    $('#foto11').hover(function(){
        $('#descr11').show();
    },function(){
        $('#descr11').hide();
    });

    $('#foto12').hover(function(){
        $('#descr12').show();
    },function(){
        $('#descr12').hide();
    });

    $('#foto13').hover(function(){
        $('#descr13').show();
    },function(){
        $('#descr13').hide();
    });

    $('#foto14').hover(function(){
        $('#descr14').show();
    },function(){
        $('#descr14').hide();
    });

    $('#foto15').hover(function(){
        $('#descr15').show();
    },function(){
        $('#descr15').hide();
    });

    $('#foto16').hover(function(){
        $('#descr16').show();
    },function(){
        $('#descr16').hide();
    });

    $('#foto17').hover(function(){
        $('#descr17').show();
    },function(){
        $('#descr17').hide();
    });

    $('#foto18').hover(function(){
        $('#descr18').show();
    },function(){
        $('#descr18').hide();
    });

    $('#foto19').hover(function(){
        $('#descr19').show();
    },function(){
        $('#descr19').hide();
    });

    $('#foto20').hover(function(){
        $('#descr20').show();
    },function(){
        $('#descr20').hide();
    });

    $('#foto21').hover(function(){
        $('#descr21').show();
    },function(){
        $('#descr21').hide();
    });

    $('#foto22').hover(function(){
        $('#descr22').show();
    },function(){
        $('#descr22').hide();
    });

    $('#foto23').hover(function(){
        $('#descr23').show();
    },function(){
        $('#descr23').hide();
    });

    $('#foto24').hover(function(){
        $('#descr24').show();
    },function(){
        $('#descr24').hide();
    });

    $('#foto25').hover(function(){
        $('#descr25').show();
    },function(){
        $('#descr25').hide();
    });

    $('#foto26').hover(function(){
        $('#descr26').show();
    },function(){
        $('#descr26').hide();
    });

    $('#foto27').hover(function(){
        $('#descr27').show();
    },function(){
        $('#descr27').hide();
    });

    $('#foto28').hover(function(){
        $('#descr28').show();
    },function(){
        $('#descr28').hide();
    });

    $('#foto29').hover(function(){
        $('#descr29').show();
    },function(){
        $('#descr29').hide();
    });

    $('#foto30').hover(function(){
        $('#descr30').show();
    },function(){
        $('#descr30').hide();
    });

    $('#foto31').hover(function(){
        $('#descr31').show();
    },function(){
        $('#descr31').hide();
    });

    $('#foto32').hover(function(){
        $('#descr32').show();
    },function(){
        $('#descr32').hide();
    });

    $('#foto33').hover(function(){
        $('#descr33').show();
    },function(){
        $('#descr33').hide();
    });

    $('#foto34').hover(function(){
        $('#descr34').show();
    },function(){
        $('#descr34').hide();
    });

    $('#foto35').hover(function(){
        $('#descr35').show();
    },function(){
        $('#descr35').hide();
    });

    $('#foto36').hover(function(){
        $('#descr36').show();
    },function(){
        $('#descr36').hide();
    });


    /* POPUPS DE HOTELES */
    $(".FotoCarrusel").click(function(event){
        $("#popupResHotel img").attr("src", event.target.getAttribute("src"));
        document.querySelector("#popupResHotel h2").innerHTML = event.target.getAttribute("data-resName");
        $("#visitarResHotel").attr("href", event.target.getAttribute("data-pagWeb"));
        $("#popupResHotel img").attr("data-id", event.target.getAttribute("id"));

        modal.style.display = "block";
        $("#popupResHotel").show();
    });


    /**array valores guardar en cookies */
    var datosCookie = ["Usuario","Contrasena","Nombre","Apellido","Email","Fecha","Imagen","Dir"];

    $('#formAlta').submit(function(event){
        event.preventDefault();
        var valido = true;

        /* verificar con html los inputs*/
        // for (var i = 0; i < document.forms['formSignUp'].length; i++) {
        //     console.log("Campo: " + document.forms['formSignUp'][i]);
        // }



        for (var i = 0; i < datosCookie.length; i++) {
            var item = document.forms['formAlta']["Usuario"];
            console.log("reviso "+item.value);
                if(!item.checkValidity())
                    valido = false;
        }

        /* verificamos el checkbox*/
        if(valido && document.forms['formAlta']['conditions'].checked){

            if(localStorage.length === 0)
            {
                $.getJSON("./users.json", function(users){
                    register(users);
                });
            }
            else
            {
                register(JSON.parse(localStorage.getItem("JSONusuarios")));
            }
        }
        else {
            alert("Por favor rellene los campos correctamente y acepte las condiciones");
        }

        $('#close').click();


    });

    $('#formLogin').submit(function(event){
        event.preventDefault();

        if(localStorage.length === 0)
        {
            $.getJSON("./users.json", function(users){
                logIn(users);
            });
        }
        else
        {
            logIn(JSON.parse(localStorage.getItem("JSONusuarios")));
        }

    });

})


//Funcion para generar los popup de formulario
function generarpopup(tipo_form){

    if(tipo_form == 0){
        loadSignUp();
    }else if(tipo_form == 1){
        loadLogIn();
    }else if(tipo_form == 2){

        $('#Faq').show();
        console.log("POPUP");
    }
}

function loadSignUp()
{
    document.getElementById("formAlta").reset();
    $('#formSignUp').show();
}

function loadLogIn()
{
    document.getElementById("formLogin").reset();
    $('#formLogInDiv').show();
}

function loadUserMenu()
{
    $("#registro").hide();
    $("#login").hide();
    $('#close').click();
    // alert("Hola "+getCookie("usuario"));
    // document.getElementById("nombre").innerText = "Hola " + getCookie("usuario");
    if(getCookie("imagen") !== "")
        $("#userMenu img").attr("src", getCookie("imagen"));
    else
        $("#userMenu img").attr("src", "images/logo2.png");

    // $("#userMenu h2").text("Hola " + getCookie("usuario") + " &#9660;");

    document.querySelector("#userMenu h2").innerHTML = getCookie("usuario") + "    &#9660;";

    $("#userMenu").css("display", "flex");

}

/* funciones para hacer login y hacer registro */
function logIn(users) //users: JSON con los usuarios
{
    var username = $("#formLogin input[name=email-login]").val();
    var password = $("#formLogin input[name=password-login]").val();

    if(typeof(users[username]) !== "undefined")
    {
        if(users[username].contrasena == password)
        {
            //guardar cookies
            var entries = Object.entries(users[username]);
            for(var i = 0; i < entries.length; i++)
                setCookie(entries[i][0], entries[i][1], 365);

            loadUserMenu();
        }
        else
        {
            alert("La contraseña no es correcta");
        }
    }
    else
    {
        alert("El usuario no existe");
    }
}

function register(users) //users: JSON con los usuarios
{
    if(typeof(users[document.forms["formAlta"]["Usuario"].value]) === "undefined")
    {
        var newUser = new Object();
        newUser.usuario = document.forms["formAlta"]["Usuario"].value;
        newUser.contrasena = document.forms["formAlta"]["Contrasena"].value;
        newUser.nombre = document.forms["formAlta"]["Nombre"].value;
        newUser.apellido = document.forms["formAlta"]["Apellido"].value;
        newUser.email = document.forms["formAlta"]["Email"].value;
        newUser.fechaNac = document.forms["formAlta"]["Fecha"].value;
        newUser.imagen = document.forms["formAlta"]["Imagen"].value;
        newUser.direccion = document.forms["formAlta"]["Dir"].value;

        users[document.forms["formAlta"]["Usuario"].value] = newUser;

        console.log("del register");

        /* Como no puedo guardar un fichero físico guardo
        el json resultante en el localStorage
        Esto es una solucion improvisada */
        localStorage.setItem("JSONusuarios", JSON.stringify(users));
    }
    else
    {
        alert("El nombre de usuario ya está en uso")
    }

    console.log(localStorage);
}

/* funciones registro y login con cookies */
/**creo la cookie */
function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

/* verificar si existe un usuario logueado.
si lo hay verifica si la cookie es correcta*/
function checkCookie() {

    var cookieValues = document.cookie.split(";");

    if(cookieValues.length != 8)
        return false;

    if(getCookie("usuario") === "")
        return false;

    // $.getJSON("./users.json", function(users){
    //
    //     var username = getCookie("usuario");
    //
    //     if(typeof(users[username]) !== "undefined")
    //     {
    //         var jsonValues = Object.entries(users[username]);
    //
    //         for(var i = 0; i < jsonValues.length; i++)
    //             if(cookieValues[i].split("=")[0] !== jsonValues[i][0] ||
    //             cookieValues[i].split("=")[1] !== jsonValues[i][1])
    //                 return false;
    //     }
    //     else
    //         return false;
    // });

    return true;
}

/**Sacar valores por parametro */
function getCookie(cname) {
//console.log("entro en getcookie");
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
    // console.log(i+ca[i]);
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
        //  console.log(c);
            return c.substring(name.length, c.length);
        }
    }
// console.log("no habia na");
    return "";
}

function clearCookies()
{
    var cookies = document.cookie.split(";");
    for (var i = 0; i < cookies.length; i++)
        setCookie(cookies[i].split("=")[0], cookies[i].split("=")[1], -1);
}
